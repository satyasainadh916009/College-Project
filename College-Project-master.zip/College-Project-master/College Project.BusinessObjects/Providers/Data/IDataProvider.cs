﻿using System;
using System.Collections.Generic;
using System.Text;

namespace College_Project.BusinessObjects.Providers.Data
{
    public interface IDataProvider
    {
    }
}
