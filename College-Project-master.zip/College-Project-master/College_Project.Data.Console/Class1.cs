﻿using System;

namespace College_Project.Data.Console
{
    public class Class1
    {
    }
}
