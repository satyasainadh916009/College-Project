﻿using College_Project.Infra;
using System;
using System.Collections.Generic;
using System.Text;

namespace College_Project.Entities
{
    public class UserType:EntityBase
    {
        public string UserTypeName { get; set; }
    }
}
