﻿using System;
using System.Collections.Generic;
using System.Text;

namespace College_Project.Infra.Enums
{
    public enum EResponseStatus
    {
        Success=1,
        Failed,
        Partial
        //another one to be added
        
    }
}

//Test for Jira 
