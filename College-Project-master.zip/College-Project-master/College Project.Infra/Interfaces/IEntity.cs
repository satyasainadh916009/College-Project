﻿using System;
using System.Collections.Generic;
using System.Text;

namespace College_Project.Infra.Interfaces
{
    public interface IEntity
    {

    }
}
